<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tipo de Parpado</title>
</head>
<body>
    <fieldset>
        <legend> Test de Tipo de Parpado</legend>
        <form action="parpado.php" method="post">
            <p>1.-¿Tus ojos tienen pliegue?</p>
            <p>Si <input type="radio" name="r1" value="Si"></p>
            <p>No <input type="radio" name="r1" value="No"></p>

            <p>2.-Imagina una linea recta a traves de tu ojo¿La esquina izquierda esta hacia abajo?</p>
            <p>Si <input type="radio" name="r2" value="Si"></p>
            <p>No <input type="radio" name="r2" value="No"></p>

            <p>3.-¿El pliegue de tu ojo se oculta cuando cierras el ojo?</p>
            <p>Si <input type="radio" name="r3" value="Si"></p>
            <p>No <input type="radio" name="r3" value="No"></p>

            <p>4.-Cuando abres el ojo ¿La parte blanca se ve abajo o arriba del iris?</p>
            <p>Si <input type="radio" name="r4" value="Si"></p>
            <p>No <input type="radio" name="r4" value="No"></p>

            <p><input type="submit"  value="Enviar"></p>

        </form>
    </fieldset>
</body>
</html>